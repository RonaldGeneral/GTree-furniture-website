# GTree-furniture-website
-we try to make the website AS REAL AS POSSIBLE by adding features and implementing database in our website.

Main page to open: "GTree-furniture-website\homepage\homepage.html"

Recommended browser: Google Chrome
Recommended Resolution: 1200 px x 800 px


Opening the website
-------------------
**The website need to be opened in visual studio code live server.**
Make sure visual studio code is installed and the live server extension is installed.

1. Open file manager and find the folder "GTree-furniture-website"
2. right click the "Gtree-furniture-website" folder and select "Open with Code"
3. Visual Studio Code will be opened. 
4. Scroll through the file explorer on the left side of VS code and find "homepage.html" in the "homepage" folder.
5. Open the "homepage.html" and the html document will appear on the right side of vs code.
6. Right click anywhere within the html document and select "Open with Live server".
7. The website will be opened in your browser,make sure it is Google Chrome.


Functionable website features
-----------------------------
-Track orders
-Login
-Add to cart in product catalog
-Shopping cart
-Checkout
-Invoice (to generate new order ID)
-Livechat 


Unavailable features
--------------------
-Personal Particular
-register
-searchbar


Available Track Order ID
------------------------
AAA-2345-333X
BBB-7890-222X
CCC-1234-111X
Track order ID which is generated based on order


Available user account
----------------------
UserID: John123
Password: abc123aabb


livechat command
----------------
/dark    -   toggle dark mode
/mute    -   toggle mute and unmute notification sounds